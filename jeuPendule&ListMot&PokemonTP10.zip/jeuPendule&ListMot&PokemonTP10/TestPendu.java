/**
 * Classe TestPendu
 * @version 25/03/2025
 */
import java.util.Scanner;

public class TestPendu {
    public static void main(String[] args) {
        Scanner clavier = new Scanner(System.in);
        ListMots listeMots = null;

        try {
            listeMots = new ListMots("dicoPendu.txt");
            System.out.println("Fichier dicoPendu.txt chargé avec succès !");
        } catch (Exception e) {
            System.out.println("Impossible de lire le fichier dicoPendu.txt. Vous pourrez uniquement saisir un mot.");
        }

        while (true) {
            System.out.println("\nMenu :");
            System.out.println("1. Jouer avec un mot tiré aléatoirement");
            System.out.println("2. Saisir un mot pour jouer");
            System.out.println("3. Quitter");
            System.out.print("Votre choix : ");
            int choix = clavier.nextInt();
            clavier.nextLine(); 

            if (choix == 3) {
                System.out.println("Au revoir !");
                break;
            }

            String mot = null;
            if (choix == 1) {
                if (listeMots != null) {
                    mot = listeMots.motAleatoire();
                    System.out.println("Un mot a été tiré aléatoirement !");
                } else {
                    System.out.println("Le fichier n'a pas pu être chargé. Vous devez saisir un mot.");
                    continue;
                }
            } else if (choix == 2) {
                System.out.println("Saisir le mot d'au moins 4 lettres à deviner : ");
                mot = clavier.nextLine();
                if (mot.length() < 4) {
                    System.out.println("Le mot doit contenir au moins 4 lettres !");
                    continue;
                }
            } else {
                System.out.println("Choix invalide. Veuillez réessayer.");
                continue;
            }

     
            try {
                Pendu p = new Pendu(mot);
                char lettre;
                do {
                    p.afficherEssais();
                    System.out.print("\nEntrez une lettre : ");
                    lettre = clavier.nextLine().charAt(0);
                } while (p.jouer(lettre) && !p.estFini());
                p.afficherEssais();

                if (p.estFini()) {
                    System.out.println("Gagné !!!!!");
                } else {
                    System.out.println("Perdu :-(");
                    System.out.println("La solution était : " + p.getMot());
                }

                if (choix == 2 && listeMots != null) {
                    listeMots.ajouterMot(mot);
                    System.out.println("Le mot a été ajouté à la liste et au fichier.");
                }
            } catch (PenduException e) {
                System.out.println(e.getMessage());
                if (e.getMotInvalide() != null) {
                    System.out.println("Le mot invalide est : " + e.getMotInvalide());
                }
            }
        }

        clavier.close();
    }
}