import java.util.Scanner;

public class TestListMots {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Entrez le nom du fichier :");
        String nomFichier = scanner.nextLine();

        ListMots listMots = new ListMots(nomFichier);

        System.out.println("Mots actuels dans le fichier :");
        for (String mot : listMots.getListeMots()) {
            System.out.println(mot);
        }

        System.out.println("Entrez des mots à ajouter (tapez 'STOP' pour arrêter) :");
        while (true) {
            String mot = scanner.nextLine();
            if (mot.equalsIgnoreCase("STOP")) {
                break;
            }
            listMots.ajouterMot(mot);
        }

        System.out.println("Mots dans le fichier après ajout :");
        for (String mot : listMots.getListeMots()) {
            System.out.println(mot);
        }

        scanner.close();
    }
}