import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Vector;

public class ListMots{
    private String nomFichier;
    private Vector<String> listeMots;


    public ListMots(String nomFichier) {
        this.nomFichier = nomFichier;
        listeMots = new Vector<String>();
        lireFichier();
    }


    private void lireFichier() {
        try {
            Scanner scanner = new Scanner(new File(nomFichier));
            while (scanner.hasNextLine()) {
                String mot = scanner.nextLine();
                listeMots.add(mot);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Le fichier n'a pas pu être trouvé.");
        }
    }


    public String motAleatoire() {
        int index = (int) (Math.random() * listeMots.size());
        return listeMots.get(index);
    }


    public void ajouterMot(String mot) {
        if (!listeMots.contains(mot)) {
            listeMots.add(mot);
            try {
                PrintWriter writer = new PrintWriter(new FileWriter(nomFichier, true));
                writer.println(mot);
                writer.close();
            } catch (IOException e) {
                System.out.println("Erreur lors de l'écriture dans le fichier.");
            }
        } else {
            System.out.println("Le mot est déjà présent dans la liste.");
        }
    }
    public Vector<String> getListeMots() {
        return listeMots;
    }

}
