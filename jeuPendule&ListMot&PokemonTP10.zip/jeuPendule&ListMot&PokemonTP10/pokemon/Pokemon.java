/**
 * Classe Pokemon
 * @author Jessica Jonquet
 * @version 25/03/2025
 */
import java.io.*;

public class Pokemon {
    public static void main(String[] args) {
        try {
            DataInputStream clavier = new DataInputStream(System.in);

            int deux = 0;
            System.out.println("Entrez un nombre...");
            deux = clavier.readInt();
            System.out.println(deux);

            try (FileOutputStream f = new FileOutputStream("toto.txt")) {
                f.write(deux);
                f.write(2000);
            } catch (FileNotFoundException e) {
                System.err.println("File not found: " + e.getMessage());
            }

            int[] u = new int[1];
            u[2] = 33; // Provoque une ArrayIndexOutOfBoundsException
            u = new int[7];
            u[7] = 99 / deux; // Provoque une ArithmeticException si deux == 0
        } catch (IOException e) {
            System.err.println("IOException: " + e.getMessage());
        } catch (ArithmeticException e) {
            System.err.println("ArithmeticException: " + e.getMessage());
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("ArrayIndexOutOfBoundsException: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Exception: " + e.getMessage());
        }
    }
}