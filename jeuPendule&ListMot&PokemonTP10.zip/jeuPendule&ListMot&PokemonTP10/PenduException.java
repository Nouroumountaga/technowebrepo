
public class PenduException extends Exception {
    private String motInvalide;

    public PenduException(String message) {
        super(message);
    }

    public PenduException(String message, String motInvalide) {
        super(message);
        this.motInvalide = motInvalide;
    }

    public String getMotInvalide() {
        return motInvalide;
    }
}