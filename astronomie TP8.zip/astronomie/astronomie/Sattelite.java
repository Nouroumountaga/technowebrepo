 package astronomie;

public class Sattelite implements ISatellite{
    private String nom;
    private double masse;
    private double diametre;
    private double vitesseRotation;
    private double distance;
    private double periodeRotation;
    private Astre astreReference;

    @Override
    public Astre getAstreReference() {
        return astreReference;
    }

    @Override
    public double getVitesseRevolution() {
        return 0.0;
    }

    public Sattelite(String nom, double masse, double diametre, double vitesseRotation, double distance, double periodeRotation) {
        this.nom = nom;
        this.masse = masse;
        this.diametre = diametre;
        this.vitesseRotation = vitesseRotation;
        this.distance = distance;
        this.periodeRotation = periodeRotation;
    }

    public String getNom() {
        return nom;
    }

    public double getMasse() {
        return masse;
    }

    public double getDiametre() {
        return diametre;
    }

    public double getVitesseRotation() {
        return vitesseRotation;
    }

    public double getDistance() {
        return distance;
    }

    public double getPeriodeRotation() {
        return periodeRotation;
    }
    public String toString() {
        return "Satellite{" +
                "nom='" + nom + '\'' +
                ", masse=" + masse +
                ", diametre=" + diametre +
                ", vitesseRotation=" + vitesseRotation +
                ", distance=" + distance +
                ", periodeRotation=" + periodeRotation +
                '}';
    }
    
}