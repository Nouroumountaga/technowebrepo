package personne;


public class Vacataire {
    private String nom;
    private String prenom;
    private double salaire;
    private String entreprise;

    public Vacataire(String nom, String prenom, double salaire, String entreprise) {
        this.nom = nom;
        this.prenom = prenom;
        this.salaire = salaire;
        this.entreprise = entreprise;
    }

    public Vacataire(Vacataire v) {
        this.nom = v.nom;
        this.prenom = v.prenom;
        this.salaire = v.salaire;
        this.entreprise = v.entreprise;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public double getSalaire() {
        return salaire;
    }

    public String getEntreprise() {
        return entreprise;
    }

    public String toString() {
        return "Vacataire " + nom + " " + prenom + " (salaire : " + salaire + ", entreprise : " + entreprise + ")";
    }   
}