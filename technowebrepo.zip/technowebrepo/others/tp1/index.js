const t = [1,2,3];
console.log(t);
console.log("case 1:" , t[0] , "case 4:" , t[4]) // case 1 : 1 , case 4: undefined; 
console.log('taille tab , ' , t.length) // taille tab , 2;

const user = {
    prenom : "john",
    nom:"doe"
}

console.log(user);
const keys = Object.keys(user) // [ prenom , nom ];
console.log(a); // undefined
