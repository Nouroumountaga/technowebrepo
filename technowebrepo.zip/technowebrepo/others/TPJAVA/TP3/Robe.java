/**
 * Enum&eacute;ration <b>Robe</b>
 * Cette &eacute;num&eacute;ration permet d'indiquer les couleur de robe possible
 * @author Jessica Jonquet
 * @version 13/03/2025
 */
public enum Robe{
	BLANCHE,
	SABLE,
	MARRON,
	CHOCOLAT,
	NOIRE;
}