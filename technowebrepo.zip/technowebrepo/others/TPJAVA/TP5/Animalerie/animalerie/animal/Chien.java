package animalerie;

public class Chien extends Mamiferes {
    public Chien (Nom nom , int nbPattes , String crier){
            super (nom,4,"waafff wafff");
        };
    }
    public Chien (){
        super();
    }
}
