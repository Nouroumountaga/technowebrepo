package animalerie;

public class Chat extends Mamiferes {
    public Chat (Nom nom , int nbPattes , String crier){
            super (nom,4,"miaouuuuuuu");
        };
    }
    public Chat (){
        super();
    }

}
