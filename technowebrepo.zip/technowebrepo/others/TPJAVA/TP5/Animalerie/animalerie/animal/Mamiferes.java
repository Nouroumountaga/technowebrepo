package animalerie;

public class Mamiferes extends Animal {
    public Mamiferes (Nom nom , int nbPattes , String crier){
            super (nom,nbPattes,crier);
        };
    }
    public Mamiferes (){
        super ();
    }
}
