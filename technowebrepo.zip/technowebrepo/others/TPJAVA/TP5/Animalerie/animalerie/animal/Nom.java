enum Nom {
    Médor
    Azraël
    LeChat
};
