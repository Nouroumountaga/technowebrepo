package astronomie;

public class Astre implements IAstre {
    private String nom;
    private double masse;
    private double diametre;
    private double vitessRotation;
    private int nbSattelite;
    private Sattelite[] satellite;  

    public Astre (String nom, double masse, double diametre, double vitessRotation, int nbSattelite){
        this.diametre = diametre;
        this.masse = masse;
        this.nbSattelite = nbSattelite;
        this.vitessRotation =  vitessRotation;
        this.nom = nom;
    }

    public String getNom(){
        return this.nom;
    }
    public double getMasse() {
        return this.masse;
    }
    public double getDiametre (){
        return this.diametre;
    }
    public double getVitesseRotation (){
        return this.vitessRotation;
    }
    public int getNombreSatellites(){
        return nbSattelite;
    }
    public Sattelite getSatellite(int n){
        if (n < 0 || n >= nbSattelite) {
            return null;
        }
        return satellite[n];
    }
    @Override
    public void ajouterSatellite(Sattelite s) {
        if (satellite == null) {
            satellite = new Sattelite[10];
        }
        if (nbSattelite < satellite.length) {
            satellite[nbSattelite] = s;
            nbSattelite++;
        } else {
            System.out.println("Impossible d'ajouter un nouveau satellite, le tableau est plein.");
        }
    }

    @Override
    public void afficher() {
        System.out.println(this.toString());
    }
    public String toString(){
        return "Astre{" +
                "nom='" + nom + '\'' +
                ", masse=" + masse +
                ", diametre=" + diametre +
                ", vitessRotation=" + vitessRotation +
                ", nbSattelite=" + nbSattelite +
                '}';
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public void setMasse(double masse) {
        this.masse = masse;
    }
}